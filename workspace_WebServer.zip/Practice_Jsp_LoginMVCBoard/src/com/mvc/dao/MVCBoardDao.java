package com.mvc.dao;

import common.JDBCTemplate;

public class MVCBoardDao extends JDBCTemplate {

}
