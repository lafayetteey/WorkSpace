package com.practice;

public class Test {

	public static void main(String[] args) {
		PracticeExample pe = new PracticeExample();
		//pe.sample1();
		//pe.sample2();
		//pe.sample3();
		//pe.sample4();
		pe.sample05();
		
		
	}

}
