package com.example2;

public class TestMain {

	public static void main(String[] args) {
		CastingSample cs = new CastingSample();
		
		cs.printUniCode();
		cs.calculatorScores();
	}

}
