package com.event.part03_changepanel;

import java.awt.Color;

import javax.swing.JPanel;

public class Panel1 extends JPanel {
	public Panel1() {
		this.setSize(300, 200);
		this.setBackground(Color.BLUE);
		
		this.setVisible(true);
	}
}
