package com.event.part03_changepanel;

public class Run {

	public static void main(String[] args) {
		new MainFrame();
	}

}
