package com.event.part02_howToUse;

public class B_Run {

	public static void main(String[] args) {
		new B_OtherClass();
		
	}

}
