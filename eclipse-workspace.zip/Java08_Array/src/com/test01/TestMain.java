package com.test01;

public class TestMain {

	public static void main(String[] args) {
	 ArrayTest01 test = new ArrayTest01();
	 
	 	//test.testArray();
	 	//	test.testArray2();
	 		test.testArray3();
	 
	}

}
