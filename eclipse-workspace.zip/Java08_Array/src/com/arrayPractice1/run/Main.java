package com.arrayPractice1.run;

import com.arrayPractice1.sample.ArraySample;

public class Main {
	public static void main(String[] args) {
		ArraySample test = new ArraySample();
		
		//test.test1();
		//test.test1_1();
		//test.test1_2();
		//test.test2();
		//test.test2_1();
		//test.test2_2();
		//test.test3();
		//test.test3_1();
		//test.test4();
		//test.test5();
		test.test8();
	}	
}
