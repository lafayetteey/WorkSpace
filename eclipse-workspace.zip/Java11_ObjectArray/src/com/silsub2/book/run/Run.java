package com.silsub2.book.run;

import com.silsub2.book.controller.BookManager;

public class Run {

	public static void main(String[] args) {
		BookManager bm = new BookManager();
		bm.menu();
	}

}
