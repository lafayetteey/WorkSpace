package com.silsub3.member.view;

import java.util.Scanner;

import com.silsub3.member.model.vo.Member;

//�޴� ȭ�� ������ Ŭ����
public class MemberMenu {
	Scanner sc = new Scanner(System.in);
	Member mManager = new Member();
	
	public MemberMenu() {
	}
	
	public void mainMenu() {
		
	}
	public void searchMenu() {
		
	}
	public void sortMenu() {
		
	}
	public void modifyMenu() {
		
	}
}
