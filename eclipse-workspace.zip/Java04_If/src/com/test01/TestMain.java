package com.test01;

public class TestMain {

	public static void main(String[] args) {
		IfTest01 it = new IfTest01();
		IfTest02 it1 = new IfTest02();
		IfTest03 it2 = new IfTest03();
		
		//it2.test();
		//it2.testIfElseIf();
		it2.testIfElseIf2();
		
		//it.testIf();
		//it1.testIf01();
		//it.testIfElse();
		//it1.testIfElse2_1();
		//it1.testIfElse2_2();
		// it1.testIfElse3();
		
	}

}
