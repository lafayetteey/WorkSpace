package com.test.oi.part04_objectStream;

public class MTest {

	public static void main(String[] args) {
		TestStream ts = new TestStream();
		
		//ts.fileSave();
		ts.fileOpen();
	}

}
