package com.test.oi.part04_objectStream;

public class Run {

	public static void main(String[] args) {
		ObjStream obj = new ObjStream();
		//obj.fileSave();
	obj.fileOpen();
		
	}

}
