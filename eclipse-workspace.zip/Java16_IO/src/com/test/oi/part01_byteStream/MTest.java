package com.test.oi.part01_byteStream;

public class MTest {

	public static void main(String[] args) {
		TestByteStream tbs = new TestByteStream();
		
		//tbs.fileSave();
		tbs.fileOpen();
	}

}
