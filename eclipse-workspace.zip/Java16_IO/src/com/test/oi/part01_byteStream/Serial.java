package com.test.oi.part01_byteStream;

import java.io.Serializable;

public class Serial implements Serializable {
	
	private byte[] barr = null;
}
