package com.test.oi.part02_charStream;

public class MTest {

	public static void main(String[] args) {
		TestCharStream tc = new TestCharStream();
		//tc.fileSave();
		tc.fileOpen();
//		tc.fileWrite();
		//tc.fileRead();
	}

}
