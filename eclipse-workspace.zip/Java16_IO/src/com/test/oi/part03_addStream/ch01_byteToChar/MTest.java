package com.test.oi.part03_addStream.ch01_byteToChar;

public class MTest {

	public static void main(String[] args) {
		TestStream ts = new TestStream();
		
		//ts.input();
		ts.output();
	}

}
