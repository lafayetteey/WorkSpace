package com.test.oi.part03_addStream.ch02_buffer;

public class MTest {

	public static void main(String[] args) {
		TestStream ts = new TestStream();
		ts.output();
		ts.input();
	}

}
