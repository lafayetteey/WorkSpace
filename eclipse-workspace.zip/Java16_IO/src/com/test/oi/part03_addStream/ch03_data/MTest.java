package com.test.oi.part03_addStream.ch03_data;

public class MTest {

	public static void main(String[] args) {
		TestStream ts = new TestStream();
	
		//ts.output();
		//EOFE (end of file exception) 발생
		ts.inout();
	}

}
