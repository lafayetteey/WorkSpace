package com.gui.part02_layout;

public class Run {
	public static void main(String[] args) {
		//new A_BorderLayout();
		//new B_FlowLayout();
		//new C_GridLayout();
		//new D_CardLayout();
		new E_PanelLayout();
	}
}
