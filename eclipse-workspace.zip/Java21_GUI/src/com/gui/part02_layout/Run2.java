package com.gui.part02_layout;

public class Run2 {

	public static void main(String[] args) {
		//new BorderLayoutTest();
		//new FlowLayoutTest();
		//new GridLayoutTest();
		new PanelLayoutTest();
	}

}
