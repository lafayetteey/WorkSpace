package com.gui.part01_container;

public class Run {
	public static void main(String[] args) {
		//new JFrameTest();
		
		new JFrameTest2().showMainFrame();
		
	}
}
