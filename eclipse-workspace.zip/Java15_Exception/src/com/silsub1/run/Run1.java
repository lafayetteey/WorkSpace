package com.silsub1.run;

import com.silsub1.exception.CharCheckExceptione;
import com.silsub1.view.Console;

public class Run1 {
	public static void main(String args[]) throws CharCheckExceptione {
		Console cs = new Console();
		
		cs.charInput();
	}

}
