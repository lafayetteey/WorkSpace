package com.silsub1.run;

import com.silsub1.exception.CharCheckException;
import com.silsub1.view.ConsoleIO;

public class Run {
	public static void main(String args[] ) throws CharCheckException {
		ConsoleIO cs = new ConsoleIO();
		
		cs.charInput();
	}
}
