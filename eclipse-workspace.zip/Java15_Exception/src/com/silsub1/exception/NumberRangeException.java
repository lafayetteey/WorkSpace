package com.silsub1.exception;

public class NumberRangeException extends Exception {
	public NumberRangeException() {
		
	}
	public NumberRangeException(String msg) {
		super(msg);
	}
}
