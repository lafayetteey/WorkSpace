package com.silsub1.exception;

public class CharCheckExceptione extends Exception {
	public CharCheckExceptione() {
		
	}
	public CharCheckExceptione(String msg) {
		super(msg);
	}
}
