package com.test.chap01_runtimeException;

public class MTest {

	public static void main(String[] args) {
		RunExcepPrac rep = new RunExcepPrac();
		
		//rep.ArithEx();
		rep.ClassNArrayEx();
	}

}
