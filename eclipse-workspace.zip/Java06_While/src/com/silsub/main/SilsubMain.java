package com.silsub.main;

public class SilsubMain {

	public static void main(String[] args) {
		Munjae test = new Munjae();
		
	//	test.test1();
	//	test.test2();
	//test.test3();
	//	test.test4();
	//	test.test6();
		test.test7();
	}

}
