package com.poly.test.test02;

public abstract class Base {
	public Base() {
		System.out.println("base ����");
	}
	public abstract void start();
	public abstract void stop();
}
