package com.poly.test.test03;

public class MTest {

	public static void main(String[] args) {
		Animal cat = new Cat();
		cat.bark();
		cat.eat("��ġ");
		Animal dog = new Dog();
		dog.bark();
		dog.eat("���");
	}

}
