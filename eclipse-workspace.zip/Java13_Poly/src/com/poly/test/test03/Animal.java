package com.poly.test.test03;

public interface Animal {
	
	//�߻�޼ҵ�
	public void bark();
	void eat(String feed);
	
}
