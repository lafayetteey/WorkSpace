package com.poly.test.test07;

public interface Display {
	public void display();
}
