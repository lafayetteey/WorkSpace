package com.poly.test.test07;

public interface Job {
	public String jobId = "IT";
	public void jobLoc(String loc);

}
