package com.poly.test.test06;

public interface Area {
	//static final
	String print = "����: ";
	public void print();
	public void make();
	
	
	
}
