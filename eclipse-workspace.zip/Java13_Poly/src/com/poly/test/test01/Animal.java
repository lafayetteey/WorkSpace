package com.poly.test.test01;

public abstract class Animal {
	//�߻� �޼ҵ� 
	public abstract void bark();
	
	
	public void eat(String animal) {
		System.out.println(animal + " �Դ´�.");
	}
	
	
}
