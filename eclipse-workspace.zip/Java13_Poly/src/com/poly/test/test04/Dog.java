package com.poly.test.test04;

public class Dog extends Animal {
	@Override
	public void bark() {
		System.out.println("�۸�");
	}
	public void bite() {
		System.out.println("������.");
	}
	

}
