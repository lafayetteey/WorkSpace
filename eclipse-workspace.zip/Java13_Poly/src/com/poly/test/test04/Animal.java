package com.poly.test.test04;

public abstract class Animal {
	public abstract void bark();
	public void eat(String feed) {
		System.out.println(feed + " �Դ´�.");
	}
}
