package com.poly.silsub1.shape.run;

import com.poly.silsub1.shape.controller.ShapeManager;

public class Run {

	public static void main(String[] args) {
		ShapeManager sp = new ShapeManager();
		
		//sp.calcShape();
		sp.calcShapeArray();
		
		
	}

}
