package com.poly.silsub1.shape.run;

public class TestIShape {
	public static void main(String args[]) {

	}
}
