package com.project.run;

import com.project.view.LibraryMenu;

public class LibraryMain {
	public static void main(String[] args) {
		new LibraryMenu().mainMenu();
	}
}