package com.silsub1.run;

import com.silsub1.model.Practice;
import com.silsub1.model.Sample;

public class Main {

	public static void main(String[] args) {
		Sample test = new Sample();
		Practice test1 = new Practice();
		
		test1.Practice4();
		

	}

}
