package com.test01;

public class Main {

	public static void main(String[] args) {
		DeArrayTest test = new DeArrayTest();
		DeArrayTest02 test1 = new DeArrayTest02();
		
		test1.test01();
		
		//test.testInit();
		//test.testInit2();
		//test.testInit3();
		//test.testInit4();
	}
	

}
