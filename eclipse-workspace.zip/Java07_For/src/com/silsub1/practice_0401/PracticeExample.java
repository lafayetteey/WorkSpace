package com.silsub1.practice_0401;

public class PracticeExample {

	public static void main(String[] args) {
		Practice test = new Practice();
		Practice01 test1 = new Practice01();
		//test.pritnStar();
		//test.printStar2();
		//test1.selectMenu();
		test1.countInputCharacter();
	}

}
