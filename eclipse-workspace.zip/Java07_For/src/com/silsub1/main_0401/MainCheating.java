package com.silsub1.main_0401;

import com.silsub1.example_0401.ForWhileCheating;

public class MainCheating {

	public static void main(String[] args) {
		ForWhileCheating test = new ForWhileCheating();
		
		test.selectMenu();
	}

}
