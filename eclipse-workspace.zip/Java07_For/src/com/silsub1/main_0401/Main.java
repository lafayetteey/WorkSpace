package com.silsub1.main_0401;

import com.silsub1.example_0401.ForWhile;

public class Main {

	public static void main(String[] args) {
		 ForWhile test = new ForWhile();
		 
		 //test.printStar1();
		 //test.printStar1_1();
		 //test.printStar2();
		 //	test.selectMenu();
		// test.countinputCharacter();
		 test.countCharacters();
	}
	

}
