package com.test.chap01_encapsulation;

public class ScoreMain {

	public static void main(String[] args) {
		Score sc = new Score();
		
		
		sc.sum();
		sc.avg1();
		sc.maxPoint();
		sc.minPoint();
		sc.information();
	}

}
