package com.test.chap02_class.publicClass.model;

public class PublicClassTest {
	
	public void test() {
		System.out.println("public class ���� test() ȣ��...");

	}
}
