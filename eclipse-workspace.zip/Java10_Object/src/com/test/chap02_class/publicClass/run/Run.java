package com.test.chap02_class.publicClass.run;

import com.test.chap02_class.publicClass.model.PublicClassTest;

public class Run {

	public static void main(String[] args) {
		PublicClassTest test = new PublicClassTest();
		test.test();
		
	}
}
