package com.test.chap02_class.dafaultClass.model;

public class Run {

	public static void main(String[] args) {
		DefaultClassTest de = new DefaultClassTest();
		
		de.test();
	}

}
