package com.collection.listSilsub.run;

import com.collection.listSilsub.view.PTMenubyTeacher;
import com.collection.listSilsub.view.ParkingTowerMenu;

public class Run {

	public static void main(String[] args) {
		ParkingTowerMenu ptm = new ParkingTowerMenu();
		PTMenubyTeacher pt = new PTMenubyTeacher();
		
		//pt.mainMenu();
		ptm.mainMenu();
	}

}
