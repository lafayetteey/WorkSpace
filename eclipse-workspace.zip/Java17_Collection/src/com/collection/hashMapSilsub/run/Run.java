package com.collection.hashMapSilsub.run;

import com.collection.hashMapSilsub.view.ParkingTowerMenu;

public class Run {

	public static void main(String[] args) {
		ParkingTowerMenu pt = new ParkingTowerMenu();
		pt.mainMenu();
	}

}
