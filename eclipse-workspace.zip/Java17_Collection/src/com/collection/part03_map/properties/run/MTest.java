package com.collection.part03_map.properties.run;

import com.collection.part03_map.properties.controller.TestProperties;

public class MTest {

	public static void main(String[] args) {
		TestProperties tp = new TestProperties();
		
		//tp.testProp();
		tp.testProp2();
	}

}
