package com.collection.part03_map.hashmap.run;

import com.collection.part03_map.hashmap.controller.TestHashMap;

public class Run {

	public static void main(String[] args) {
		TestHashMap hmap = new TestHashMap();
		
		//hmap.testHashMap();
		hmap.testHashMap2();
	}

}
