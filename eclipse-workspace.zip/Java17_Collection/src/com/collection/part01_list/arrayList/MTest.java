package com.collection.part01_list.arrayList;

public class MTest {

	public static void main(String[] args) {
		ArrayListTest alt = new ArrayListTest();
		
		//alt.testArrayList();
		alt.testArrayListSort();
	}

}
