package com.collection.part01_list.arrayListSort.run;

import com.collection.part01_list.arrayListSort.controller.ScoreManager;

public class MTest {

	public static void main(String[] args) {
		ScoreManager sm = new ScoreManager();
		
		sm.scoreSort();
	}

}
