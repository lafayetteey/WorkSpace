package com.practice;

public class Test {

	public static void main(String[] args) {
		Practice01 test = new Practice01();
		Practice02 test1 = new Practice02();
		Practice03 test2 = new Practice03();
		
		//test.sample();
		//test1.sample2();
		//test2.sample3();
		test2.sample4();
	}

}
