package com.practice2;

public class IfExample {

	public static void main(String[] args) {
		If test = new If();
		If01 test1 = new If01();
		//test.IfExam();
		//test.IfExam01();
		test1.testIfElseIf2();
	}

}
