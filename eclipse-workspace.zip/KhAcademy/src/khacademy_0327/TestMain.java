package khacademy_0327;

public class TestMain {

	public static void main(String[] args) {
		Example ex = new Example();
		
		ex.example01();
		ex.example02();
		ex.example03();
	}

}
