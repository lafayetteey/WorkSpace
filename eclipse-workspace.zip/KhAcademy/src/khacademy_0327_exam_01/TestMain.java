package khacademy_0327_exam_01;

public class TestMain {

	public static void main(String[] args) {
		Practice pr = new Practice();
		
		pr.integer();
		pr.double1();
		pr.keyCode();
		
		}

}
