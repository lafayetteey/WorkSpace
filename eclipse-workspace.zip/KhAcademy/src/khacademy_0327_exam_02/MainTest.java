package khacademy_0327_exam_02;

public class MainTest {

	public static void main(String[] args) {
		CastingSample cs = new CastingSample();
		
		cs.printUniCode();
		cs.calculatorScore();
		
	}

}
