package khacademy_0327_exam_04;

public class TestMain {

	public static void main(String[] args) {
		CastingSample cs = new CastingSample();
		
		cs.printUniCode();
		cs.calculatorScore();

	}

}
