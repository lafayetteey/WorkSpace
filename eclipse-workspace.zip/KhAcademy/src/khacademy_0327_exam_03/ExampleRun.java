package khacademy_0327_exam_03;

public class ExampleRun {

	public static void main(String[] args) {
		Example ex = new Example();
		
		ex.Integer();
		ex.double01();
		ex.keyCode();

	}

}
