package com.run;

import com.view.Menu;


public class Run {
	public static void main(String[] args) {
		new Menu();
	}

}

