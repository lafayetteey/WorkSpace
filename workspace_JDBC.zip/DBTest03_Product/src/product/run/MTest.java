package product.run;

import product.view.ProductView;

public class MTest {

	public static void main(String[] args) {
		new ProductView();
	}

}
