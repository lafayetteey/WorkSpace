package com.test01;

public class DBTest06_Run {
	public static void main(String[] args) {
		
		
		
		

	}
}
