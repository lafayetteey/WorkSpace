package common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCTemplate {
	public static Connection getConnection() {
		return null;
	}
	
	public static void close (Connection con) {
		
	}
	public static void close(Statement stm) {
		
	}
	
	public static void close(ResultSet rs) {
		
	}
	
	public static void commit(Connection con) {
		
	}
	public static void rollBack(Connection con) {
		
	}
}
