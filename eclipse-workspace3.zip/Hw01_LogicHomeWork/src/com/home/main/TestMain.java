package com.home.main;

import com.home.view.Menu;

public class TestMain {

	public static void main(String[] args) {
		new Menu().displayMenu();
		
		
	}

}
