package com.silsub1.run;

import com.silsub1.model.Sample;

public class Main {

	public static void main(String[] args) {
		Sample sp = new Sample();	
		
		//sp.munjea1();
		//sp.munjae2();	
		//sp.munjae3();		
		sp.munjea4();
	}

}
