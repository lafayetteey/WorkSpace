package com.threadPrcatice;

import java.util.Calendar;

public class TestThread {

	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
	}
}
