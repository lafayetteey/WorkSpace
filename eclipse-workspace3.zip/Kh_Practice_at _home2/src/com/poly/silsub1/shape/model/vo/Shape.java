package com.poly.silsub1.shape.model.vo;

public abstract class Shape {
	public abstract double area();
	public abstract double perimeter();
}
