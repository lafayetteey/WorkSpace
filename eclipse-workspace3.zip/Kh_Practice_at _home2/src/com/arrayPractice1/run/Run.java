package com.arrayPractice1.run;

import com.arrayPractice1.sample.ArraySample;

public class Run {

	public static void main(String[] args) {
		ArraySample as = new ArraySample();
		
		//as.test1();
		//as.test2();
		//as.test3();
		//as.test4();
		as.test5();
	}

}
