package com.hw3.controller.tv;

public interface Tv {
	public int volumeUp();
	public int volumeDown();
}
