package com.silsub1.tv.model.vo;

public interface TV {
	public int volumUp();
	public int volumeDown();
}
