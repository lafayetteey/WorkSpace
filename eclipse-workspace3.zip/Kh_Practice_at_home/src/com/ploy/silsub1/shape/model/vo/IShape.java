package com.ploy.silsub1.shape.model.vo;

public interface IShape {
	public double area();
	public double perimeter();
}
