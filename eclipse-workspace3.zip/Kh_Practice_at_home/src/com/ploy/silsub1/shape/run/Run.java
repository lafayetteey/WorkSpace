package com.ploy.silsub1.shape.run;

import com.ploy.silsub1.shape.controller.ShapeManager;

public class Run {

	public static void main(String[] args) {
		ShapeManager sm = new ShapeManager();
		
		sm.calcShapeArray();
	}

}
