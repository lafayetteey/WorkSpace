package com.collection.listSilsub.Run;

import com.collection.listSilsub.view.ParkingTowerMenu;

public class Run {

	public static void main(String[] args) {
		ParkingTowerMenu pt = new ParkingTowerMenu();
		
		pt.mainMenu();
	}

}
