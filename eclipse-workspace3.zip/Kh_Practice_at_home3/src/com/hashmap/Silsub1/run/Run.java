package com.hashmap.Silsub1.run;

import com.hashmap.Silsub1.view.ParkingTowerMenu;

public class Run {

	public static void main(String[] args) {
		ParkingTowerMenu pm = new ParkingTowerMenu();
		pm.mainMenu();
	}

}
