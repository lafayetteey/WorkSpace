package com.io.silsub2.run;

import com.io.silsub2.view.NoteMenu;

public class Run {

	public static void main(String[] args) {
		NoteMenu nm = new NoteMenu();
		
		nm.menu();
	}

}
