package com.arrayList.silsub_run;

import com.arrayList.silsub_view.ParkingTowerMenu;

public class Run {
	public static void main(String args[]) {
		ParkingTowerMenu pm = new ParkingTowerMenu();
		
		pm.mainMenu();
	}
}
