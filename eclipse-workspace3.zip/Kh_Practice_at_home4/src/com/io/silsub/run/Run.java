package com.io.silsub.run;

import com.io.silsub.model.dao.FileIOTest;

public class Run {

	public static void main(String[] args) {
		FileIOTest io = new FileIOTest();
		io.fileOpen();
	}

}
